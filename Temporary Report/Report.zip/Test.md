
![logo](logo.png){width="300cm"}
\
**BRAC University**\
Department of Computer Science and Engineering\

------------------------------------------------------------------------

\
**Artificial Intelligence**\
*Course Project*

------------------------------------------------------------------------

**Student Information:**\
Name: Abdullah Al Mazid Zomader\
ID: 24241189\
Section: 20\
**Course Information:**\
Course Code: CSE-422\
Course Title: Artificial Intelligence\
Date: 05 January, 2026


# Introduction

Write your introduction here.

![Person in a hand.](hand.png){#fig:myimage width="100%"}

# Dataset description

Write content here.

# Dataset pre-processing

Write content here.

# Dataset splitting

Write content here.

# Model training & testing

Write content here.

## k-Nearest Neighbors

Write content here.

## Decision Tree

Write content here.

## Logistic Regression

Write content here.

## Linear Regression

Write content here.

## Naive Bayes

Write content here.

## Neural Network

Write content here.

## K-Means Clustering

Write content here.

# Model selection/Comparison analysis

Write content here.

# Conclusion

Write content here.
